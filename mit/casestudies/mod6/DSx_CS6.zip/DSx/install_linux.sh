#!/bin/bash
# OSX Installation
sudo apt-get install build-essential
sudo pip install -r requirements.txt