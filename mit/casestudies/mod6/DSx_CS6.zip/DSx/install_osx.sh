#!/bin/bash
# OSX Installation
brew install gcc@5 --without-multilib
sudo pip install -r requirements.txt
